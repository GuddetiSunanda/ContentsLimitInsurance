﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContentsLimitInsurance.Models
{
    public class ContentsContext: DbContext
    {
        public ContentsContext(DbContextOptions<ContentsContext> options): base(options)
        {

        }

        public DbSet<ItemInsurance> Items { get; set; }
        public DbSet<CategoryInsurance> Categories { get; set; }
    }
}
