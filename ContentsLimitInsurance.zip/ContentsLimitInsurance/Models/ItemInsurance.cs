﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ContentsLimitInsurance.Models
{
    public class ItemInsurance
    {
        [Key]
        public int ItemID { get; set; }

        [Required(ErrorMessage ="Please enter the name of the item")]
        [DisplayName("Name of the item")]
        public string Name { get; set; }

        [Required]
        [DisplayName("Price")]
        public decimal Value { get; set; }

        public CategoryInsurance CategoryInsurance { get; set; }
    }
}
