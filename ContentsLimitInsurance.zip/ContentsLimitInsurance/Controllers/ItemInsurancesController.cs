﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ContentsLimitInsurance.Models;
using System.Runtime.CompilerServices;

namespace ContentsLimitInsurance.Controllers
{
    public class ItemInsurancesController : Controller
    {
        private readonly ContentsContext _context;

        public ItemInsurancesController(ContentsContext context)
        {
            _context = context;
        }

        // GET: ItemInsurances
        public async Task<IActionResult> Index()
        {
            List<CategoryInsurance> categories = new List<CategoryInsurance>();
            List<ItemInsurance> items = new List<ItemInsurance>();

            categories = (from C in _context.Categories
                          select C).OrderBy(c => c.CategoryName).ToList();

            items = (from C in _context.Items
                     select C).Distinct().OrderBy(c => c.CategoryInsurance.CategoryName).ToList();

           var distinctCategoriesWithData = items.Select(x=>x.CategoryInsurance.CategoryID).Distinct();

          
            ViewBag.ListOfCats = distinctCategoriesWithData;
            return View(await _context.Items.Include("CategoryInsurance").OrderBy(c => c.CategoryInsurance.CategoryName).ToListAsync());
        }


        // GET: ItemInsurances/Create
        public IActionResult AddOrEdit(int Id = 0)
        {
            List<CategoryInsurance> categories = new List<CategoryInsurance>();
            categories = (from C in _context.Categories
                          select C).ToList();
            categories.Insert(0, new CategoryInsurance { CategoryID = 0, CategoryName="Select..."});
            ViewBag.ListOfCategories = categories;

            if(Id == 0)
             return View(new ItemInsurance());
            else
             return View(_context.Items.Find(Id));
        }

        // POST: ItemInsurances/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrEdit([Bind("ItemID,Name,Value,CategoryInsurance")] ItemInsurance itemInsurance)
        {
            if (ModelState.IsValid)
            {
                int SelectValue = itemInsurance.CategoryInsurance.CategoryID;
                ViewBag.SelectedValue = SelectValue;

                List<CategoryInsurance> categories = new List<CategoryInsurance>();
                categories = (from C in _context.Categories
                              select C).ToList();
                categories.Insert(0, new CategoryInsurance { CategoryID = 0, CategoryName = "Select..." });
                ViewBag.ListOfCategories = categories;

                _context.Entry<ItemInsurance>(itemInsurance).State = EntityState.Added;

                if (itemInsurance.ItemID == 0)
                {
                    
                    _context.Add(itemInsurance);
                }
                    
                else
                {
                    //_context.Entry<ItemInsurance>(itemInsurance).State = EntityState.Added;
                    _context.Update(itemInsurance);
                }
                  
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }
            return View(itemInsurance);
        }

        // GET: ItemInsurances/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            var item = await  _context.Items.FindAsync(id);
            _context.Items.Remove(item);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

    }
}
